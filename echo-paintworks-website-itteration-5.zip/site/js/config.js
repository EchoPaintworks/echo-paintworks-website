// Echo Paintworks — shared config
// These two values are SAFE to expose in browser code (they're the
// "public" keys, protected by Row Level Security on the database side).
// Never put secret keys (Stripe secret, Twilio auth token, Resend key,
// Supabase service_role key) in this file or anywhere in /site — those
// only ever live in Cloudflare Pages environment variables, used by
// the /functions code.
window.ECHO_CONFIG = {
  SUPABASE_URL: "https://gqzqbrmprwssodopmxan.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_FsBUI6Pvpj2rSE3f7ea-Tw_WYU3Z3xX"
};
