// /api/signup-notify
// Called right after a customer signs up. Sends:
//  1. A welcome email to the customer (via Resend)
//  2. A welcome text to the customer, if they gave a phone number (via Twilio)
//  3. An email alert to you, so you know someone new signed up
//
// Secrets used here (set in Cloudflare Pages > Settings > Environment variables):
//   RESEND_API_KEY, RESEND_FROM_EMAIL, ADMIN_EMAIL,
//   TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER

export async function onRequestPost({ request, env }) {
  try {
    const { full_name, email, phone } = await request.json();
    const firstName = (full_name || '').split(' ')[0] || 'there';

    const tasks = [];

    // 1. Welcome email to customer
    tasks.push(sendEmail(env, email, `Welcome to Echo Paintworks, ${firstName}!`,
      `<p>Hi ${firstName},</p>
       <p>Thanks for creating an account with Echo Paintworks! You can log in anytime to see your project's status and message us directly.</p>
       <p>If you need anything at all, just reply to this email or reach out at 778-212-8528 — happy to help.</p>
       <p>Talk soon,<br>Evan @ Echo Paintworks</p>`
    ));

    // 2. Welcome text to customer, if phone provided
    if (phone) {
      tasks.push(sendSms(env, phone,
        `Hi ${firstName}, thanks for signing up with Echo Paintworks! We'll keep you posted right here as your project moves along. Reply anytime with questions. Reply STOP to opt out.`
      ));
    }

    // 3. Alert email to admin
    tasks.push(sendEmail(env, env.ADMIN_EMAIL, `New signup: ${full_name || email}`,
      `<p>New account created on echopaintworks.com:</p>
       <p>Name: ${full_name || '—'}<br>Email: ${email}<br>Phone: ${phone || '—'}</p>`
    ));

    await Promise.allSettled(tasks);

    return new Response(JSON.stringify({ ok: true }), { headers: { 'Content-Type': 'application/json' } });
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: String(err) }), { status: 500, headers: { 'Content-Type': 'application/json' } });
  }
}

async function sendEmail(env, to, subject, html) {
  return fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${env.RESEND_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      from: env.RESEND_FROM_EMAIL,
      to,
      subject,
      html
    })
  });
}

async function sendSms(env, to, body) {
  const creds = btoa(`${env.TWILIO_ACCOUNT_SID}:${env.TWILIO_AUTH_TOKEN}`);
  return fetch(`https://api.twilio.com/2010-04-01/Accounts/${env.TWILIO_ACCOUNT_SID}/Messages.json`, {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${creds}`,
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: new URLSearchParams({
      To: normalizePhone(to),
      From: env.TWILIO_PHONE_NUMBER,
      Body: body
    })
  });
}

function normalizePhone(raw) {
  const digits = raw.replace(/\D/g, '');
  if (raw.trim().startsWith('+')) return raw.trim();
  if (digits.length === 10) return `+1${digits}`;
  if (digits.length === 11 && digits.startsWith('1')) return `+${digits}`;
  return `+${digits}`;
}
