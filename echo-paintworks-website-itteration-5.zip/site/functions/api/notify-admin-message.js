// /api/notify-admin-message
// Called when a customer sends a message through their dashboard
// (as opposed to texting). Just emails you so you see it promptly —
// same fast-follow-up idea as the SMS notifications.

export async function onRequestPost({ request, env }) {
  try {
    const { body } = await request.json();

    await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: env.RESEND_FROM_EMAIL,
        to: env.ADMIN_EMAIL,
        subject: `New dashboard message`,
        html: `<p>A customer sent a message through their dashboard:</p><p>${body}</p><p>Reply from your admin dashboard.</p>`
      })
    });

    return new Response(JSON.stringify({ ok: true }), { headers: { 'Content-Type': 'application/json' } });
  } catch (err) {
    return new Response(JSON.stringify({ ok: false }), { status: 500 });
  }
}
