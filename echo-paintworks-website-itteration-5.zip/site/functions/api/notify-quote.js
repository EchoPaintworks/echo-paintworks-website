// /api/notify-quote
// Called when a logged-in customer submits the "Get a Quote" form.
// Emails you the full details so you see it right away.

export async function onRequestPost({ request, env }) {
  try {
    const { name, email, phone, address, property_type, service, timeline, details } = await request.json();

    await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: env.RESEND_FROM_EMAIL,
        to: env.ADMIN_EMAIL,
        subject: `New quote request: ${name || email}`,
        html: `
          <p><strong>${name || '—'}</strong> requested a quote.</p>
          <p>Email: ${email || '—'}<br>Phone: ${phone || '—'}</p>
          <p>Address: ${address || '—'}<br>
             Property type: ${property_type || '—'}<br>
             Service: ${service || '—'}<br>
             Timeline: ${timeline || '—'}</p>
          <p>Details: ${details || '—'}</p>
          <p>This customer's project now shows as "Requested" in your admin dashboard.</p>
        `
      })
    });

    return new Response(JSON.stringify({ ok: true }), { headers: { 'Content-Type': 'application/json' } });
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: String(err) }), { status: 500 });
  }
}
