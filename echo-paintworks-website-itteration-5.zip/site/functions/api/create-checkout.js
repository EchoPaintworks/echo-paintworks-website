// /api/create-checkout
// Called when you click "Create payment link" for a customer in the
// admin dashboard. Creates a Stripe Checkout page and returns its URL.

export async function onRequestPost({ request, env }) {
  try {
    const { amount, customer_email, project_id } = await request.json();
    if (!amount || amount <= 0) {
      return new Response(JSON.stringify({ ok: false, error: 'Invalid amount' }), { status: 400 });
    }

    const params = new URLSearchParams();
    params.append('mode', 'payment');
    params.append('success_url', 'https://echopaintworks.com/dashboard.html?paid=1');
    params.append('cancel_url', 'https://echopaintworks.com/dashboard.html');
    params.append('customer_email', customer_email);
    params.append('line_items[0][price_data][currency]', 'cad');
    params.append('line_items[0][price_data][product_data][name]', 'Echo Paintworks — Project Invoice');
    params.append('line_items[0][price_data][unit_amount]', Math.round(amount * 100).toString());
    params.append('line_items[0][quantity]', '1');
    params.append('metadata[project_id]', project_id || '');

    const res = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${env.STRIPE_SECRET_KEY}`,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: params
    });

    const data = await res.json();
    if (!res.ok) {
      return new Response(JSON.stringify({ ok: false, error: data.error?.message || 'Stripe error' }), { status: 400 });
    }

    return new Response(JSON.stringify({ ok: true, url: data.url, session_id: data.id }), { headers: { 'Content-Type': 'application/json' } });
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: String(err) }), { status: 500 });
  }
}
