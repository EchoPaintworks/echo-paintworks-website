// /api/stripe-webhook
// Set this URL in Stripe: Developers > Webhooks > Add endpoint
//   https://echopaintworks.com/api/stripe-webhook
// Listen for event: checkout.session.completed
// Stripe will give you a "Signing secret" (whsec_...) when you create it —
// set that as STRIPE_WEBHOOK_SECRET in Cloudflare Pages environment variables.
//
// This uses the Supabase SERVICE ROLE key to update the project as paid,
// since there's no logged-in user here — Stripe is calling us directly.

export async function onRequestPost({ request, env }) {
  const rawBody = await request.text();
  const signatureHeader = request.headers.get('stripe-signature');

  const valid = await verifyStripeSignature(rawBody, signatureHeader, env.STRIPE_WEBHOOK_SECRET);
  if (!valid) {
    return new Response('Invalid signature', { status: 400 });
  }

  const event = JSON.parse(rawBody);

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const projectId = session.metadata?.project_id;

    if (projectId) {
      const supabaseUrl = env.SUPABASE_URL;
      const serviceKey = env.SUPABASE_SERVICE_ROLE_KEY;
      await fetch(`${supabaseUrl}/rest/v1/projects?id=eq.${projectId}`, {
        method: 'PATCH',
        headers: {
          apikey: serviceKey,
          Authorization: `Bearer ${serviceKey}`,
          'Content-Type': 'application/json',
          Prefer: 'return=minimal'
        },
        body: JSON.stringify({ status: 'paid', updated_at: new Date().toISOString() })
      });

      // Let admin know a payment came in.
      await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from: env.RESEND_FROM_EMAIL,
          to: env.ADMIN_EMAIL,
          subject: `Payment received`,
          html: `<p>A payment just came through for project ${projectId}.</p>`
        })
      }).catch(() => {});
    }
  }

  return new Response(JSON.stringify({ received: true }), { headers: { 'Content-Type': 'application/json' } });
}

async function verifyStripeSignature(payload, sigHeader, secret) {
  if (!sigHeader) return false;
  const parts = Object.fromEntries(sigHeader.split(',').map(p => p.split('=')));
  const timestamp = parts.t;
  const expectedSig = parts.v1;
  if (!timestamp || !expectedSig) return false;

  const signedPayload = `${timestamp}.${payload}`;
  const key = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(secret),
    { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  );
  const sigBuffer = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(signedPayload));
  const computedSig = [...new Uint8Array(sigBuffer)].map(b => b.toString(16).padStart(2, '0')).join('');

  return computedSig === expectedSig;
}
