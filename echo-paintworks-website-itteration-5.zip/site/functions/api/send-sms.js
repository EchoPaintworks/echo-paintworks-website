// /api/send-sms
// Called when you (admin) reply to a customer in the dashboard.
// Sends the reply as a real text message via Twilio.

export async function onRequestPost({ request, env }) {
  try {
    const { to, body } = await request.json();
    if (!to || !body) {
      return new Response(JSON.stringify({ ok: false, error: 'Missing to/body' }), { status: 400 });
    }

    const creds = btoa(`${env.TWILIO_ACCOUNT_SID}:${env.TWILIO_AUTH_TOKEN}`);
    const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${env.TWILIO_ACCOUNT_SID}/Messages.json`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${creds}`,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: new URLSearchParams({
        To: normalizePhone(to),
        From: env.TWILIO_PHONE_NUMBER,
        Body: body
      })
    });

    const data = await res.json();
    return new Response(JSON.stringify({ ok: res.ok, twilio: data }), { headers: { 'Content-Type': 'application/json' } });
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: String(err) }), { status: 500 });
  }
}

function normalizePhone(raw) {
  const digits = raw.replace(/\D/g, '');
  if (raw.trim().startsWith('+')) return raw.trim();
  if (digits.length === 10) return `+1${digits}`;
  if (digits.length === 11 && digits.startsWith('1')) return `+${digits}`;
  return `+${digits}`;
}
