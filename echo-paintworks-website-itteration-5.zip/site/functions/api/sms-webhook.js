// /api/sms-webhook
// Set this URL as the "A Message Comes In" webhook on your Twilio number:
// https://echopaintworks.com/api/sms-webhook
//
// When a customer texts your business number, Twilio calls this URL.
// We look up which customer that phone number belongs to, save the
// message, and email you so you see it right away.
//
// This needs the Supabase SERVICE ROLE key (not the anon key) because
// there's no logged-in user here — it's Twilio calling us directly.
// Set SUPABASE_SERVICE_ROLE_KEY in Cloudflare Pages environment variables
// (find it in Supabase: Project Settings > API > service_role key).

export async function onRequestPost({ request, env }) {
  try {
    const formData = await request.formData();
    const from = formData.get('From');
    const body = formData.get('Body');
    const messageSid = formData.get('MessageSid');

    const supabaseUrl = env.SUPABASE_URL;
    const serviceKey = env.SUPABASE_SERVICE_ROLE_KEY;

    // Find the customer profile with this phone number.
    // We try a couple of formats since phones can be stored inconsistently.
    const digits = from.replace(/\D/g, '').slice(-10); // last 10 digits
    const profileRes = await fetch(
      `${supabaseUrl}/rest/v1/profiles?phone=ilike.*${digits}*&select=id,full_name,email`,
      { headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}` } }
    );
    const profiles = await profileRes.json();

    if (profiles && profiles.length) {
      const customer = profiles[0];

      await fetch(`${supabaseUrl}/rest/v1/messages`, {
        method: 'POST',
        headers: {
          apikey: serviceKey,
          Authorization: `Bearer ${serviceKey}`,
          'Content-Type': 'application/json',
          Prefer: 'return=minimal'
        },
        body: JSON.stringify({
          customer_id: customer.id,
          sender: 'customer',
          body,
          channel: 'sms',
          twilio_sid: messageSid
        })
      });

      await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from: env.RESEND_FROM_EMAIL,
          to: env.ADMIN_EMAIL,
          subject: `New text from ${customer.full_name || customer.email}`,
          html: `<p><strong>${customer.full_name || customer.email}</strong> texted:</p><p>${body}</p><p>Reply from your admin dashboard.</p>`
        })
      });
    } else {
      // Unknown number — still alert admin so nothing gets missed.
      await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from: env.RESEND_FROM_EMAIL,
          to: env.ADMIN_EMAIL,
          subject: `Text from unknown number: ${from}`,
          html: `<p>${from} texted: ${body}</p>`
        })
      });
    }

    // Twilio expects TwiML (XML) back, even if empty, or it may show an error in logs.
    return new Response('<Response></Response>', { headers: { 'Content-Type': 'text/xml' } });
  } catch (err) {
    return new Response('<Response></Response>', { headers: { 'Content-Type': 'text/xml' } });
  }
}
